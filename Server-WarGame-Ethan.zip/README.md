# File Server

cd into this directory and run

```{bash}
php -S 0.0.0.0:8080
```

to launch the server.

## Vulnerabilities

The code contains 3 unique vulnerabilities for you to find and fix. You have to fix the code yourself, but it shouldn't be too hard to spot.

As a hint, there is one in admin.php, login.php, and index.php!
